const { default: mongoose } = require('mongoose')
const mongo = require('mongoose')
mongo.connect("mongodb://127.0.0.1:27017/loginsignup")
.then(()=>{
    console.log('mongodb connected')
})
.catch(()=>{
    console.log('failed to connect!')
})

const loginSchema = new mongoose.Schema({
    name :{
        type : String,
        require : true
    },

    password :{
        type : String,
        require : true
    }
})

const collection = new mongoose.model("logincollection",loginSchema)
module.exports = collection