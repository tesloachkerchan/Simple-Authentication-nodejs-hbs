const express = require('express')
const collection = require('./mongodb')
const app = express()
let path = require('path')
let hbs = require('hbs')
const templatePath = path.join(__dirname,'../template')
app.use(express.urlencoded({extended:false}))

app.use(express.json())
app.set('view engine','hbs')
app.set('views',templatePath)

app.get('/',(req,res)=>{
    res.render('login')
})

app.get('/signup',(req,res)=>{
    res.render('signup')
})

app.post('/signup',async (req,res) =>{
   const data = {
    name:req.body.name,
    password:req.body.password
   }
   if(data.name==null && data.password==null){
    res.send("all fill required")
   }
   else{
    await collection.insertMany([data])
    res.render("home")
   }
})
app.post('/login',async (req,res) =>{
    try{
        const check = await collection.findOne({name:req.body.name})
        if(check.password===req.body.password){
            res.render("home")
        }else{
            res.send("wrong password")
        }
        
    }
    catch{
        res.send("wrong detail")
    }
 })


app.listen(3000,()=>{
    console.log("server is listing on port 3000")
})